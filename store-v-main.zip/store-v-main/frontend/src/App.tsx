import "./App.scss";
import Layout from "./components/layouts/Layout";

function App() {
  return (
    <>
      <Layout></Layout>
    </>
  );
}

export default App;
