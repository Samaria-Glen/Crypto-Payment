export const navData = [
  { id: 0, name: "All", value: "all", to: "all-products" },
  { id: 1, name: "Hoodie", value: "Hoodie", to: "hoodie" },
  { id: 2, name: "T-shirt", value: "T-shirt", to: "t-shirt" },
  { id: 3, name: "Cap", value: "Cap", to: "cap" },
  { id: 4, name: "Hat", value: "Hat", to: "hat" },
  { id: 5, name: "Sticker", value: "Sticker", to: "sticker" },
];
export const sizeData = ["XS", "S", "M", "L", "XL", "2XL", "3XL", "4XL", "5XL"];

