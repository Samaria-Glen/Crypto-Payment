module.exports = {
    testEnvironment: 'node'
  };